# Adversarial stress-test handoff — Mercor Hack Day

These are **5 new scenarios packaged as 6 single-answer entries**: `ADV-A`, `ADV-B`, `ADV-C`, `ADV-D`, `ADV-E.1` (shares), and `ADV-E.2` (share class). The split matches the team's existing one-entry/one-answer dataset format.

## Files
- `adversarial_tasks.yaml`: full internal evaluation metadata (`expected`, source evidence, named traps, why correct).
- `ai_prompts_only.yaml`: safe prompts and relative document paths; **use this for the model**.
- `contracts/`: six source files; paths in both YAML files resolve relative to this directory.
- `model_first_runs.csv`: blank logging sheet for new-model tests.

## Critical rules
1. Do not overwrite or replace the earlier **50/52** results; those are baseline results, not this dataset.
2. Treat these as **additional synthetic challenge scenarios grounded in real/anonymized documents**; the varied deal facts are hypothetical, not actual historical outcomes.
3. `reviewed: false` is intentional: the team should conduct final expert review, especially of date conventions, before scoring.
4. Provide only listed contract files and the `prompt` to the tested model. **Never provide `expected`, `answer`, `basis`, `evidence`, `traps` or the existing `ANSWERS.md` to the model.**
5. Use the same model for each new test; record the exact prompt, model, run date and first complete response. Do not retry to hunt for an error.
6. Keep AI question-answer accuracy and checker classification accuracy as **separate metrics**; keep baseline and stress-test results in separate rows.
7. For a questionable gold answer or valid alternative interpretation, use human review / `ESCALATE`, not automatic `REJECT`.
8. This is a legal interpretation demo, not professional legal advice. Only share startup documents with parties authorized to receive them or upload them to model providers that have the necessary permission.

## Intended gold answers (internal only)
- ADV-A: `2000-12-31`
- ADV-B: `114000`
- ADV-C: `2018-12-30`
- ADV-D: `false` (assignment without consent is not allowed)
- ADV-E.1: `205000`
- ADV-E.2: `Safe Preferred Stock`

## Integration
The team's existing YAML parser appears to use `source`, `reviewed`, `split_from`, `expected.type` and `expected.value`, so this package uses those fields. Adapt path prefix as needed when merging into the main repo. Only merge after verifying parser compatibility.
